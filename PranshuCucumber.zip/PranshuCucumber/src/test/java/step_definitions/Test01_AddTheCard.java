package step_definitions;

import io.cucumber.java.en.*;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.Select;
import pages.Homepage;
import pages.LoginPage;
import pages.ProductPage;
import utility.BrowserUtils;
import utility.ConfigurationReader;
import utility.Driver;

public class Test01_AddTheCard {

    Homepage homepage = new Homepage();
    LoginPage loginPage = new LoginPage();
    ProductPage productPage= new ProductPage();

    @Given("Users can be go to login page")
    public void users_can_be_go_to_login_page() {

        Driver.get().get(ConfigurationReader.get("url"));
        Driver.get().manage().window().maximize();
        homepage.acceptAllCookies.click();


    }

    @When("Users can be login")
    public void users_can_be_login() {

        BrowserUtils.waitForPageToLoad(20);
        homepage.loginButton.click();
        loginPage.email.sendKeys(ConfigurationReader.get("username"));
        loginPage.continueButton.click();
        loginPage.password.sendKeys(ConfigurationReader.get("password"));
        loginPage.signIn.click();


    }

    @When("Users can select product")
    public void users_can_select_product() {
        BrowserUtils.waitForPageToLoad(20);
        homepage.bestSeller.click();
        productPage.termometer.click();




    }



    @When("Users can select {int} quantity")
    public void users_can_select_quantity(Integer int1) {
        BrowserUtils.waitForPageToLoad(20);

        Select select = new Select(Driver.get().findElement(By.id("quantity")));
        select.selectByIndex(1);

    }


    @Then("Users can logout")
    public void users_can_logout() {

        BrowserUtils.hover(homepage.loginButton);
        homepage.logout.click();
        BrowserUtils.waitFor(2);

    }
}
